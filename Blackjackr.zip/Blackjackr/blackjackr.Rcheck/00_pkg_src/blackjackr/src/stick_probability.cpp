
#include <Rcpp.h>
#include <random>
using namespace Rcpp;


// [[Rcpp::export]]
double stick_probability(int count, int player_score, IntegerVector base_hand){
  int rng = 0;
  double ties = 0, dealer_wins = 0, player_wins = 0;
  std::random_device rd;
  std::mt19937 eng(rd());
  IntegerVector bc = {4,16,4,4,4,4,4,4,4,4};
  for(int i: base_hand)(bc[i] -= 1);

  int dealer_base_score = 0, dealer_base_aces = 0;
  
  if(base_hand[base_hand.size() - 1] > 1){
    dealer_base_score += base_hand[base_hand.size()-1];};
  
  if(dealer_base_score < 2){
    dealer_base_score = (11 - base_hand[base_hand.size() - 1]);
    dealer_base_aces =  (1 - base_hand[base_hand.size() - 1]);};
  

  while (count > 0) {
    IntegerVector c = {bc[0],bc[1],bc[2],bc[3],bc[4],bc[5],bc[6],bc[7],bc[8],bc[9]};//repl w/ just bc
    int dealer_score = dealer_base_score, dealer_aces =  dealer_base_aces;



    while (dealer_score < 17) {
      std::discrete_distribution<> distr({c[0],c[1],c[2],c[3],c[4],c[5],c[6],c[7],c[8],c[9]});
      rng = distr(eng);
      c[rng] -= 1;
      if(rng > 1)(dealer_score += rng);
      if(rng < 2){
        dealer_score += (11 - rng);
        dealer_aces += (1 - rng);};
      while (dealer_score > 21 and dealer_aces > 0){
        dealer_score -= 10;
        dealer_aces -= 1;};};



    if (player_score < 22){
      if (player_score > dealer_score)(player_wins += 1);
      if (player_score < dealer_score and dealer_score < 22)(dealer_wins +=1);
      if (dealer_score > 21)(player_wins +=1);
      if (player_score == dealer_score)(ties += 1);}
    if (player_score > 21)(dealer_wins += 1);

    count -= 1;
  }
  return((player_wins - dealer_wins)/(player_wins + dealer_wins + ties));
}
