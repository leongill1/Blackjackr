
#include <Rcpp.h>
#include <random>
using namespace Rcpp;


// [[Rcpp::export]]
  
IntegerMatrix winner_cards(int count, int stick_on){
  int rng, player_non_bust_wins = 0, dealer_non_bust_wins = 0; 
  IntegerMatrix data(4, 10);
  std::random_device rd;
  std::mt19937 eng(rd());
  while (count > 0) {
    int player_score = 0, dealer_score = 0, player_aces = 0, dealer_aces = 0;
    IntegerVector c {4,16,4,4,4,4,4,4,4,4};
    IntegerVector player_hand = {}, dealer_hand = {};
    
    while (dealer_score < 16) {
      std::discrete_distribution<> distr({c[0],c[1],c[2],c[3],c[4],c[5],c[6],c[7],c[8],c[9]});
      rng = distr(eng);
      c[rng] -= 1;
      dealer_hand.push_back(rng);
      if(rng > 1)(dealer_score += rng);
      if(rng < 2){
        dealer_score += (11 - rng);
        dealer_aces += (1 - rng);};
      while (dealer_score > 21 and dealer_aces > 0.5){
        dealer_score -= 10;
        dealer_aces -= 1;};};
    
    
    
    while (player_score < stick_on) {
      std::discrete_distribution<> distr({c[0],c[1],c[2],c[3],c[4],c[5],c[6],c[7],c[8],c[9]});
      rng = distr(eng);
      c[rng] -= 1;
      player_hand.push_back(rng);
      if(rng > 1)(player_score += rng);
      if(rng < 2){
        player_score += (11 - rng);
        player_aces += (1 - rng);};
      while (player_score > 21 and player_aces > 0.5){
        player_score -= 10;
        player_aces -= 1;};};
      

    if (player_score > dealer_score) {
      if (player_score < 22){
        player_non_bust_wins +=  1;
        data(0, player_hand.size()) += 1;
        for(int i: player_hand){
          data(1,  i) += 1;}}};
    
    
    if (player_score < dealer_score) {
      if (dealer_score < 22){
        dealer_non_bust_wins +=  1;
        data(2, dealer_hand.size()) += 1;
        for(int i: dealer_hand){
          data(3, i) += 1;}}};
    
    count -= 1;
  }
  data(0,9) = player_non_bust_wins;
  data(2,9) = dealer_non_bust_wins;
  return(data);
}
