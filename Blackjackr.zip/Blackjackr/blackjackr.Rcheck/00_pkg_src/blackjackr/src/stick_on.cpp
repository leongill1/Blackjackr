
#include <Rcpp.h>
#include <random>
using namespace Rcpp;


// [[Rcpp::export]]
double sim_stick_on(int n, int stick_on){
  int rng = 0;
  double ties = 0, dealer_wins = 0, player_wins = 0;
  std::random_device rd;
  std::mt19937 eng(static_cast<long unsigned int>(time(0)*rd()));
  //consider special check so we dont need to ace check every itme on dealer
  while (n > 0) {
    int player_cards = 0;
    IntegerVector c {4,16,4,4,4,4,4,4,4,4};
    int player_score = 0, dealer_score = 0, player_aces = 0, dealer_aces = 0;
    
    while (dealer_score < 17) {
      std::discrete_distribution<> distr({c[0],c[1],c[2],c[3],c[4],c[5],c[6],c[7],c[8],c[9]});
      rng = distr(eng);
      c[rng] -= 1;
      if(rng > 1)(dealer_score += rng);
      if(rng < 2){
        //2 operations here, could be removed entirely with a lot of effort send Ace to 1 and 10 to 0
        dealer_score += (11 - rng);
        dealer_aces += (1 - rng);}
      while (dealer_score > 21 and dealer_aces > 0){
        dealer_score -= 10;
        dealer_aces -= 1;}}
    
    while (player_score < stick_on or player_cards < 2) {
      player_cards += 1;
      std::discrete_distribution<> distr({c[0],c[1],c[2],c[3],c[4],c[5],c[6],c[7],c[8],c[9]});
      rng = distr(eng);
      c[rng] -= 1;
      if(rng > 1)(player_score += rng);
      if(rng < 2){
        //2 operations here, could be removed entirely with a lot of effort send Ace to 1 and 10 to 0
        player_score += (11 - rng);
        player_aces += (1 - rng);}
      while (player_score > 21 and player_aces > 0){
        player_score -= 10;
        player_aces -= 1;}}
    
    if (player_score < 22){
      if (player_score > dealer_score)(player_wins += 1);
      if (player_score < dealer_score and dealer_score < 22)(dealer_wins +=1);
      if (dealer_score > 21)(player_wins +=1);
      if (player_score == dealer_score)(ties += 1);}
    if (player_score > 21)(dealer_wins += 1);
    
    n -= 1;
  }
  return((player_wins - dealer_wins)/(player_wins + dealer_wins + ties));
}
