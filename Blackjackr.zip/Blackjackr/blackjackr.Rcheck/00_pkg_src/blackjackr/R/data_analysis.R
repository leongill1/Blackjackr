#' Given a list of data, outputs the optimal strategy for that data
#'
#' @description This function is embedded in full_strategy() but is required separately to analyse the analytically derived data to produce the optimal data.
#'
#' @param data Vector: Vector of four hashmaps with keys corresponding to all possible positions. In order they are the position player scores, the cards in the player's hand, the number of cards in the player's hand and the player's expected return when sticking at the position. 
#' @param include_double_down Logical: Whether double down is permitted in your choice of game.
#' @param include_surrender Logical: Whether surrender is permitted in your choice of game.
#'
#' @return Hashmap: Hashmap with keys representing positions and values representing the optimal choice given the specified rules.
#' @export
#'
#' @examples data_analysis(c(scores, cards, hand_size, stick_return), include_double_down = F, include_surrender = F)
data_analysis = function(data, include_double_down = F, include_surrender = F){
  invisible(options(scipen=999) )
  scores = data[[1]]
  cards = data[[2]]
  hand_size = data[[3]]#Could replace with length(cards)
  stick_return = data[[4]]
  labels = names(stick_return)
  hit_return = hash::hash(labels, -1)#Could just make equal to stick as we edit all values later

  for(i in labels){
    if(hand_size[[i]] == 2){
      if(scores[[i]] == 21){
        stick_return[[i]] = 2*stick_return[[i]]}}}#Blackjack gets double score
  
  for(current_num in 10:2){
    for(i in labels){#problem
      if(hand_size[[i]] == current_num){
        expected_value = 0
        current_hand = cards[[i]]
        hit_return[[i]] = 0
        for(j in 0:9){
          temp = as.character(as.numeric(i) + 10^j)
          p = probability(current_hand, j)
          if(p != 0){
            if(score(temp)< 22){
              if(stick_return[[temp]] >= hit_return[[temp]]){
                expected_value = expected_value + p*stick_return[[temp]]}
              if(stick_return[[temp]] < hit_return[[temp]]){
                expected_value = expected_value + p*hit_return[[temp]]}
            }}
          if(score(temp) > 21){
            expected_value = expected_value - p}
        }
        hit_return[[i]] = expected_value
      }}}

  #integrate double down
  double_return = hash::hash(labels,-2)
  if(include_double_down == T){
    for(i in labels){
      if(hand_size[[i]] == 2){
        double_value = 0
        for(j in 0:9){
          p = probability(cards[[i]], j)
          val = stick_return[[as.character(as.numeric(i) + 10^j)]]
          if(is.null(val)){double_value = double_value - p}
          if(is.null(val) == FALSE){double_value = double_value + p*val}
        }
        double_return[[i]] = double_value*2
      }}}
  surrender = hash::hash(labels, -2)
  if(include_surrender == T){
    for(i in labels){
      if(hand_size[[i]] == 2){
        surrender[[i]] = as.integer(hit_return[[i]] < -.5 & stick_return[[i]] < -.5)*5 - 2}
    }}


  #Choose optimal move for each position

  optimal = hash::hash(labels,0)

  for(i in labels){
    optimal[[i]] = which.max(c(stick_return[[i]], hit_return[[i]], double_return[[i]], surrender[[i]])) - 1}
  return(optimal)
}
