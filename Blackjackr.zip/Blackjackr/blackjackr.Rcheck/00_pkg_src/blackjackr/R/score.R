#' Determines the player score given a position's index
#'
#' @description The index describing a position is analysed and the score associated with the player hand is returned. 
#'
#' @param i Numeric/Character: The index of the position
#'
#' @return Numeric: The score of the player hand associated with the position.
#' @export
#'
#' @examples score(101100000100)
score = function(i){
  temp = 0
  high_aces = 0
  i = strsplit(as.character(i), "")[[1]]
  i = rev(i[3:length(i)])
  for(j in 3:10){
    temp = temp + as.numeric(i[j])*(j-1)}

  high_aces = as.numeric(i[1])
  temp = temp +  11*as.numeric(i[1])
  temp = temp +  10*as.numeric(i[2])
  #at most 1 soft ace so skip the loop. if you're bust just cut them all save time
  while(temp > 21 && high_aces > 0){
    temp = temp -  10
    high_aces = high_aces -  1}
  return(temp)
}
