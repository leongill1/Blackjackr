#' Determines the card frequently found in winning hands
#'
#' @description Simulates games and logs the cards in the winner's hand. Separate card pools for dealer and player. Only non-bust wins are logged.
#'
#' @param number_of_simulations Integer: The number of simulations used to approximate the proprotions of each card in winning hands. 
#' @param stick_on Integer: The value on or above which the player sticks.
#'
#' @return
#' @export
#'
#' @examples
winner_cards_par = function(number_of_simulations, stick_on){
  cores = parallel::detectCores()
  cl = parallel::makeCluster(parallel::detectCores())
  parallel::clusterExport(cl, c("winner_cards"), envir=environment())
  output =  parallel::parLapply(cl,rep(number_of_simulations/cores,cores),fun =  function(x)(winner_cards(count = as.integer(x),stick_on = as.integer(stick_on))))
  parallel::stopCluster(cl)
  output = Reduce("+", output)     
  return(output)
}