#' This function determines the accuracy of an MC strategy using the analytically derived strategy.
#'
#' @description Input an analytically strategy and an MC derived strategy and the output is the fraction of identically classified positions.
#'
#' @param strategy_1 Hash map: A strategy in the form of a hash map.
#' @param strategy_2 Hash map: A strategy in the form of a hash map. Should be derived in the opposite way to strategy 1.
#'
#' @return Numeric: The proportion of rules identically classified by both methods.
#' @export
#'
#' @examples accuracy(strategy_1, strategy_2)
acc = function(strategy_1, strategy_2){
  count = 0
  labels1 = names(strategy_1)
  labels2 = names(strategy_2)
  for(i in labels1){#go through eac hdecision
    if(is.null(strategy_2[[i]]) == F){
      if(strategy_1[[i]] == strategy_2[[i]])(count = count+ 1)#If they matach, count goes up 
  }}
  return(count/length(names(strategy_1)))#Divide by total descisions
}