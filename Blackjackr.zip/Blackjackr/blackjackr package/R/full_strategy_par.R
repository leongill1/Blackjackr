#' Obtains an optimal strategy for a specified ruleset with MC simulations done in parallel.
#' @description Produces a hash map describing the optimal strategy for blackjack. The values of the hash map 0,1,2,3 and 4 describe stick, hit, double down, surrender and split respectively.
#'
#' @param number_of_simulations Integer: The number of simulations used to approximate the expected player return when sticking on each position.
#' @param number_of_decks Integer: The number of decks used to derive the analytic values. This is the number passed to import_perfect().
#' @param blackjack_return Numeric: The amount that blackjack returns. For 3:2 the amount this is 1.5. For 2:1 this is 2.
#' @param include_double_down Logical: Whether double down is permitted in your choice of game.
#' @param include_surrender Logical: Whether surrender is permitted in your choice of game.
#' @param include_split Integer: The number of splits allowed. 0 is equivalent to not allowing splitting.
#' @param cores Integer: The number of cores to use on the computation. Default is all. 
#' @param surrender_on_blackjack  Logical: If the player can surrender, this determines if they can surrender when the dealer may have blackjack. 
#' @param verbose Logical: Whether to output the strategy as a hash map(FALSE) or as a data frame(TRUE).
#' 
#' @return Hash map: Hash map with keys representing positions and values representing the optimal choice given the specified rules.
#' @export
#'
#' @examples full_strategy_par(number_of_simulations = 10^5, include_double_down = F, include_surrender = F)
full_strategy_par = function(number_of_simulations = 1000, number_of_decks = 1,  blackjack_return = 1.5, include_double_down = F, include_surrender = F, include_split = 0, cores = parallel::detectCores(), surrender_on_blackjack = F, verbose = F){
  invisible(options(scipen=999) )#Stops R using scientific notation which I need when converting numbers to character strings
  baseline = 10^11
  dictionary = hash::hash()
  new = c()
  powers = hash("0" = 1,"1" = 10,"2" = 100,"3" = 1000,"4" = 10^4,"5" = 10^5,"6" = 10^6,"7" = 10^7,"8" = 10^8,"9" = 10^9,"10" = 10^10)
  
  # Calculate all possible positions accounting for the number of decks in play
  for(i in 0:9){
    new[as.character(baseline + powers[[as.character(i)]])] = 0
  }
  
  done = 0
  while(done == 0){
    previous = names(new)
    new = c()
    for(index in previous){
      cards =  rev(strsplit(as.character(index), "")[[1]][-c(1,2)])
      for(i in 0:9){
        current_index = as.numeric(index) + powers[[as.character(i)]]
        if(score(current_index) < 22){#Is the prospective hand valid by score?
          if(is.numeric(dictionary[[as.character(current_index +  powers[[as.character(10)]])]]) == FALSE){#Have we already seen this card. If not, proceed.
            if(as.numeric(cards[i+1])  < (number_of_decks * 4 )){#If the hand does not have more of a single card than are in the deck
              if(as.integer(cards[i+1]) <= 8){#Cant allow 10 2's or 10 aces in a hand as it breaks the indexing system
              new[as.character(current_index)] = 0
              dictionary = dealer_card(current_index , dictionary, number_of_decks)
              }
            }
          }
        }
      }
    }
    
    if(length(new) == 0){
      done = 1}
  }
 #Calculate number of player cards and score associated with each position
  scores = hash(names(dictionary), sapply(names(dictionary), score))
  hand_size = hash(names(dictionary), sapply(names(dictionary), FUN = function(x)(length(hand(x))-1)))
  
  #-------------------------------------------------------------------------
  #Calculate the cards ion play for all positions using the hand() function
  cards = hash::hash()
  labels = names(scores)
  for(i in labels){cards[[i]] = hand(i)}
  #-------------------------------------------------------------------------  
  #Calculate the sticking probabilities with MC simulation
  cl = parallel::makeCluster(cores)
  parallel::clusterExport(cl, c("stick_probability", "trial"), envir=environment())
  
  stick_return = hash::hash(labels,
                            unlist(parallel::parLapply(cl,
                                                       labels,
                                                       fun =  function(x)(stick_probability(count = number_of_simulations, number_of_decks = number_of_decks, player_score = scores[[x]] , base_hand =  cards[[x]])))))
  parallel::stopCluster(cl)
  #-------------------------------------------------------------------------   
  
  hit_return = hash::hash(labels, -1)#Could just make equal to stick as we edit all values later
  split_stick_returns = hash::hash()
  double_return = hash::hash(labels,-2)
  surrender = hash::hash(labels, -2)
  
  
  for(i in labels){
    if(hand_size[[i]] == 2){
      split_stick_returns[[i]] = stick_return[[i]]#split doesn't get blackjack. need to keep these for later
      if(scores[[i]] == 21){
        stick_return[[i]] = (blackjack_return)*stick_return[[i]]}}}#Blackjack gets double score
  #Calculate hit positions only accounting for hitting as an option
  if(include_double_down == F){ 
    for(current_num in 10:2){
      for(i in labels){#problem
        if(hand_size[[i]] == current_num){
          expected_value = 0
          current_hand = cards[[i]]
          hit_return[[i]] = 0
          for(j in 0:9){
            if(sum(current_hand == j) != 9){
            temp = as.character(as.numeric(i) + 10^j)
            p = probability(current_hand, j, number_of_decks)
            if(p != 0){
              if(score(temp)< 22){
                if(stick_return[[temp]] >= hit_return[[temp]]){
                  expected_value = expected_value + p*stick_return[[temp]]}
                if(stick_return[[temp]] < hit_return[[temp]]){
                  expected_value = expected_value + p*hit_return[[temp]]}
              }
              if(score(temp) > 21){
                expected_value = expected_value - p}
            }}}
          hit_return[[i]] = expected_value
        }}}}
  
  
  #Calculate hit positions accounting for hitting and doubling down as options at all positions 
  if(include_double_down == T){ 
    for(current_num in 10:2){
      for(i in labels){#problem
        if(hand_size[[i]] == current_num){
          expected_value = 0
          current_hand = cards[[i]]
          hit_return[[i]] = 0
          double_return[[i]] = 0
          for(j in 0:9){
            if(sum(current_hand == j) != 9){
            temp = as.character(as.numeric(i) + 10^j)
            p = probability(current_hand, j, number_of_decks)
            if(p != 0){
              if(score(temp)< 22){
                double_return[[i]] = double_return[[i]] + 2*p*stick_return[[temp]]
                expected_value = expected_value + p*max(hit_return[[temp]], stick_return[[temp]], double_return[[temp]],-1)
              }
              if(score(temp) > 21){
                expected_value = expected_value - p
                double_return[[i]] = double_return[[i]] - 2*p}
            }}}
          hit_return[[i]] = expected_value
        }}}}
  
  #integrate surrender
  if(include_surrender == T){
    surrender = hash::hash(labels, -2)
    for(i in labels){
      if(hand_size[[i]] == 2){
        if(surrender_on_blackjack == T){
          surrender[[i]] = -0.5
        }
        if(surrender_on_blackjack == F){
          if(tail(cards[[i]], 1)!= 0 && tail(cards[[i]], 1)!= 1){
            surrender[[i]] = -0.5}}    
      }}}
  
  
  #Choose optimal move for each position
  
  optimal = hash::hash(labels,0)
  optimal_value = hash::hash(labels,0)
  for(i in labels){
    moves =
      optimal[[i]] = which.max(c(stick_return[[i]], hit_return[[i]], double_return[[i]], surrender[[i]])) - 1
    optimal_value[[i]] = max(c(split_stick_returns[[i]], hit_return[[i]], double_return[[i]]))
  }
  
  #Implement splitting
  if(include_split > 0){
    split_return = hash::hash()
    for(i in 0:9){#dealer card
      for(j in 0:9){#the card of which a pair is drawn
        split_exp_return = 0
        label = as.character(10^11 + i*10^10+2*10^j)#pair label
        for(k in 0:9){#after splitting you may draw 1 of 10 hands
          p = probability(played_cards = c(i,j,j), to_draw = k, number_of_decks = number_of_decks)#You drew a pair so j has been drawn twice
          split_exp_return = split_exp_return + p*optimal_value[[as.character(10^11 + i*10^10+10^j + 10^k)]]
        }
        split_return[[label]] = split_exp_return*2#We double as we double the bet upon this action
      }
    }
    
    for(i in names(split_return)){
      if(split_return[[i]] > optimal_value[[i]]){
        optimal[[as.character(as.numeric(i) + 10^11)]] = 1#Then this position should split
      }
    }}
  #Output as data frame of hash map
  if(verbose == F){
    return(optimal)}
  
  if(verbose == T){
    return(data.frame("Scores" = values(scores), "Cards in Hand" = values(hand_size)[1:length(labels)], "Optimal Move" = values(optimal)[1:length(labels)], row.names = names(optimal)[1:length(labels)]))
  }
}
