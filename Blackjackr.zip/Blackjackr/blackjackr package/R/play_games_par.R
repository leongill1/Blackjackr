#' Estimates the expected player return per game given a strategy with MC simulations done in parallel.
#'
#' @description The strategy hashmap is inputted and the games are played from start to end. The dealer sticks on 17 or more and the player acts according to the strategy.
#'
#' @param number_of_simulations Integer: The total number of games to be simulated.
#' @param strategy Hashmap: The strategy employed by the player. Keys are positions, values are 0,1,2,3,4 for stick, hit, double down, surrender and split respectively.
#' @param blackjack_return Numeric: The amount that blackjack returns. For 3:2 the amount this is 1.5. For 2:1 this is 2.
#' @param cores Integer: The number of cores to use on the computation. Default is all. 
#' 
#' @return Numeric: An estimation of the player's expected return per game.
#' @export
#'
#' @examples play_games_par(10^7, strat)
play_games_par = function(number_of_simulations =  10^7, number_of_decks = 1, blackjack_return = 1.5, strategy = strat, cores = parallel::detectCores()){
  invisible(options(scipen=999) )
  indexes = as.numeric(names(strategy))
  optimal_moves = as.integer(hash::values(strategy))
  cl = parallel::makeCluster(cores)
  parallel::clusterExport(cl, c("play_games"), envir=environment())
  output =  parallel::parLapply(cl,rep(number_of_simulations/cores, cores),fun =  function(x)(play_games(count = as.integer(x), number_of_decks = number_of_decks, blackjack_return = blackjack_return,  index = indexes,  optimal = optimal_moves)))
  parallel::stopCluster(cl)
  return(mean(unlist(output)))
}