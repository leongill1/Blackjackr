#' Calculates the probability of a parent hand growing into a daughter hand.
#'
#' @description The probability of obtaining a daughter hand depends on the cards that have already been removed  from the deck, including that of the dealer. A hand with a {2,2} can grow into {2,2,2} with probability 2/(52 - 2).
#'
#' @param played_cards Vector: Vector containing the cards in the position. Outputted by hand(). Last element is dealer's visible card. 
#' @param to_draw Integer: The card which must be drawn to obtain the daughter hand.
#'
#' @return Numeric: The probability of obtaining the daughter hand from the parent hand.
#' @export
#'
#' @examples probability(hand(101100000100), 0)
probability = function(played_cards,to_draw, number_of_decks = number_of_decks){
  if(sum(played_cards[-1] == to_draw) != 9){
    if(to_draw == 1){
      return((16*number_of_decks - sum(played_cards == to_draw))/(52*number_of_decks - length(played_cards)))}
    if(to_draw != 1){
      return((4*number_of_decks - sum(played_cards == to_draw))/(52*number_of_decks - length(played_cards)))}}
  else{
    return(0)
  }
}
